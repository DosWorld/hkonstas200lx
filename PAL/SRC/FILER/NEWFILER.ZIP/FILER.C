/* --------------------------------------------------------------------
   Project: HP200LX FILER PROTOCOL (CLIENT) COMMUNICATIONS FOR PAL
   Module:  FILER.C
   Author:  Harry Konstas
   Started: 17. Oct. 95
   Subject: Filer communications module
   Modified:Feb.10/96: Implemented INT driven serial I/O
   -------------------------------------------------------------------- */

/* --------------------------------------------------------------------
                       standard includes
   -------------------------------------------------------------------- */

#include <dos.h>
#include <stdio.h>
#include <stdlib.h>

/* --------------------------------------------------------------------
                         local includes
   -------------------------------------------------------------------- */
#include "pal.h"
#include "palpriv.h"


/* --------------------------------------------------------------------
                             globals
   -------------------------------------------------------------------- */

static WORD async_base[4]={0x3f8,0x2f8,0x3e8,0x2e8};
static ASYNC *aport[4];
static long orgintb=0L, /* original contents of    */
            orgintc=0L; /* INT 0Bh and 0Ch vectors */


/* --------------------------------------------------------------------
                   Interrupt handler for INT 0Bh, 0Ch
   -------------------------------------------------------------------- */

static void interrupt AsyncInt(void)
{
   ASYNC *p;
   BYTE *bp;
   int i,iir;

   for(i=0;i<4;i++)  { /* step COM1 through COM4 */

      p=aport[i];

      if (p) {
         iir=inportb(p->base+IIR);
         if (iir==4) {          /* data is available from the UART      */
            bp=p->ibufhead;
            *bp=inportb(p->base+DATA); /* read the BYTE from the UART   */
            bp++;
            p->icount++;
            if (bp==p->ibufend) bp=p->ibuf;

            /* handle head-tail collision */
            if (bp==p->ibuftail) {
               p->ibuftail++;
               p->icount--;
               if (p->ibuftail==p->ibufend) p->ibuftail=p->ibuf;
            }
            p->ibufhead=bp;      /* update bufhead */
         }

         /** Send a character from the output buffer **/
         if (iir==2 && p->ocount)  {
            bp=p->obuftail;
            outportb(p->base+DATA,*bp++);
            p->ocount--;
            if (bp==p->obufend) bp=p->obuf;
            p->obuftail=bp;
         }
      }
   }
   outportb(0x20,0x20);      /* reset the 8259 interrupt controller     */
}

/* --------------------------------------------------------------------
                       Close asynchronous port
   -------------------------------------------------------------------- */

ASYNC *CloseAsync(ASYNC *p,int fc)
{
   int i;

   if (p) {
      for(i=0;i<4 && aport[i]!=p;i++);
      if (i>3) return NULL;      /* failed to close port */

      /** shut down this port **/
      outportb(p->base+MCR,fc & 3); /* disable interrupts for this port */
      outportb(p->base+IER,0);      /* disable interrupts for this port */

      /* unhook from the interrupt vector table if this is */
      /* the last port open that uses this vector.         */
      aport[i]=NULL;

      if (i==0) {
         i=inportb(0x21);   /* get the current IRQ mask             */
         i|=0x10;           /* disable IRQ 4                        */
         outportb(0x21,i);  /* set the new IRQ mask                 */
         pokel(0,0x30,orgintc);
         orgintc=0L;
      }

      else {
         for(i=1;i<4 && aport[i]==NULL;i++);
         if (i==4) {             /* no more ports are using this interrupt  */
            i=inport(0x21);      /* get the current IRQ mask                */
            i|=0x08;             /* disable IRQ 3                           */
            outportb(0x21,i);    /* set the new IRQ mask                    */
            pokel(0,0x2c,orgintb);
            orgintb=0L;
         }
      }

      /* deallocate the memory used by this port */
      free(p->ibuf);
      free(p->obuf);
      free(p);

   }
   return NULL;           /* failed to close this port                     */
}


/* --------------------------------------------------------------------
                       Open asynchronous port
   -------------------------------------------------------------------- */

ASYNC *OpenAsync(WORD port, unsigned long baud, WORD par, WORD dbits,
              WORD sbits, WORD ibufsize, WORD obufsize)
{
   int lcr;              /* Line Control Register contents */
   int i;

   /** validate port and allocate memory **/
   port--;
   if (port>3) return NULL;

   /* close it if it's already in use, */
   if (aport[port]) {    
      free(aport[port]->ibuf);
      if (aport[port]->obuf) free(aport[port]->obuf);
      free(aport[port]);
      aport[port]=NULL;
   }

   aport[port]=calloc(1,sizeof(ASYNC));
   if (aport[port]==NULL) return NULL;
   aport[port]->base=async_base[port];

   /* allocate space for the input buffer  */
   aport[port]->ibuf=malloc(ibufsize); 

   if (aport[port]->ibuf==NULL) {
      free(aport[port]);
      return NULL;
   }

   if (obufsize) {
      /* make space for the output buffer */
      aport[port]->obuf=malloc(obufsize); 
      if (aport[port]->obuf==NULL) {
         free(aport[port]->obuf);
         free(aport[port]);
         return NULL;
      }
   }

   aport[port]->ibufend=aport[port]->ibuf+ibufsize;
   aport[port]->ibufhead=aport[port]->ibuftail=aport[port]->ibuf;
   aport[port]->obufend=aport[port]->obuf+obufsize;
   aport[port]->obufhead=aport[port]->obuftail=aport[port]->obuf;

   /* Initialize the communications port. */
   outportb(aport[port]->base+IER,0); /* turn off all UART's interrupts    */
   inportb(aport[port]->base+IIR);    /* reset all UART's interrupt flags  */
   outportb(aport[port]->base+MCR,7); /* reset modem & disable interrupts  */
   inportb(aport[port]->base+DATA);   /* empty the UART's input buffer     */

   /* hook the appropriate interrupt */
   if (port) {                        /* make sure that int 0Bh is hooked  */
      if (orgintb==0L) {
         disable();
         orgintb=peekl(0,0x2c);       /* store the original contents       */
         pokel(0,0x2c,AsyncInt);      /* install the new interrupt handler */
         enable();
      }
   }

   else {                             /* make sure that int 0Ch is hooked  */
      if (orgintc==0L) {
         disable();
         orgintc=peekl(0,0x30);       /* store the original contents       */
         pokel(0,0x30,AsyncInt);      /* install the new interrupt handler */
         enable();
      }
   }

   /** set up the port itself **/
   outportb(aport[port]->base+LCR,0x80);          /*set up to set buad rate  */
   baud=(int)(115200L/(long)baud);                /*compute baud rate divisor*/
   outportb(aport[port]->base+BAUDL,baud & 0xff); /* set MSB of buad rate    */
   outportb(aport[port]->base+BAUDH,baud >> 8);   /* set LSB of baud rate    */
   lcr=(dbits-5) | (((sbits-1) & 1)<<2) | ((par & 7)<<3);
   outportb(aport[port]->base+LCR,lcr & 0x3f);  /* set data,parity,stop  */

   /** adjust the IRQ mask **/
   i=inportb(0x21);                         /* get the current IRQ mask  */
   if (port) i&=0xf7;                       /* enable IRQ 3              */
   else i&=0xef;                            /* enable IRQ 4              */
   outportb(0x21,i);                        /* set the new IRQ mask      */

   /** Reset the UART's status registers **/
   inportb(aport[port]->base+LSR);    /* reset all line status bits      */
   inportb(aport[port]->base+MSR);    /* reset all modem status bits     */

   /** tell the UART that it's OK to send interrupts **/
   if (obufsize) outportb(aport[port]->base+IER,3);   /* enable DTR      */
   else outportb(aport[port]->base+IER,1);   /* enable DATA_READY only   */
   outportb(aport[port]->base+MCR,0x0b);  /* enable ints, DTR, and RTS   */
   return aport[port];

}


/* --------------------------------------------------------------------
            Get character from ASYNC buffer  (returns -1 if none)
   -------------------------------------------------------------------- */

int GetAsync(register ASYNC *p)
{
   BYTE c,*bp;

   if (p) {
      bp=p->ibuftail;        /* point to the next BYTE in the buffer */
      if (bp==p->ibufhead)   /* if there is nothing in the buffer,   */
         return -1;          /* return EOF.                          */

      c=(BYTE)(*bp++);       /* else, get the next BYTE.             */
      p->icount--;           /* adjust the BYTE count                */

      if (bp==p->ibufend)    /* wrap if necessary                    */
         bp=p->ibuf;

      p->ibuftail=bp;
      return (unsigned)c;    /* return the value retrieved           */
   }
   return -1;
}

/* --------------------------------------------------------------------
                     Put a character into ASYNC buffer
   -------------------------------------------------------------------- */

int PutAsync(int c,register ASYNC *p)
{

   BYTE *bp;

   if (p->ocount) {
      bp=p->obufhead+1;
      if (bp==p->obufend) bp=p->obuf;
      while(bp==p->obuftail);
      *(p->obufhead)=c;
      p->obufhead=bp;
      p->ocount++;
      return c;
   }

   else {
      while((inportb(p->base+LSR) & 0x20) == 0);
      outportb(p->base+DATA,(unsigned char)c);
      return c;
   }

}


/* --------------------------------------------------------------------
                        Update CRC16 (Bisync) checksum
   -------------------------------------------------------------------- */

WORD UpdateCRC16(WORD CRC, BYTE data)
{
   WORD i, temp_crc, polynomial = 0xa001;

   temp_crc = CRC;
   temp_crc ^= data;

   for (i=0; i<8; i++)
      temp_crc = (temp_crc >> 1) ^ ((temp_crc & 1) ? polynomial : 0);

   return temp_crc;
}


/* --------------------------------------------------------------------
          Get RS232 BYTE, update CRC and return status
   -------------------------------------------------------------------- */

int GetByte(FILERCOM *pFiler, BYTE *value, WORD *Checksum)
{
   WORD v;
   WORD  far *volatile ClockLoc  = (WORD far *volatile)0x0040006cL;
   DWORD start, end, current;

   /* start counting time */
   start = *ClockLoc;
   end = (DWORD)start + TIMEOUT_DELAY / 55;

   v=-1;
   while(v==-1) {
      v=GetAsync(pFiler->pAsync);
      current = *ClockLoc;
      if(current < start) current += 65536L;

      if(current >= end) {
         return TIMEOUT;           /* timeout occured */
      }
   }

   /* '0x10' CRC trick, receive it twice */
   if((v==0x10) && (Checksum!=NULL) ) {
      v=-1;
      while(v==-1) v=GetAsync(pFiler->pAsync);
   }
   *value=v;

   /* update & return checksum */
   if(Checksum)
      *Checksum = UpdateCRC16(*Checksum, *value);

#ifdef DEBUG_PORT
   printf("r%X ", *value);
#endif

   return 0;
}


/* --------------------------------------------------------------------
                    Send RS232 BYTE / update CRC
   -------------------------------------------------------------------- */

WORD SendByte(FILERCOM *pFiler, BYTE value, WORD Checksum)
{
   /* send character */
   PutAsync(value,pFiler->pAsync);

   /* '0x10' CRC trick! got to send it twice */
   if( (Checksum!=0) && (value == 0x10) )
      PutAsync(value,pFiler->pAsync);

#ifdef DEBUG_PORT
   printf("s%X ", value);
#endif

   /* update & return checksum */
   return (UpdateCRC16(Checksum, value));
}


/* --------------------------------------------------------------------
                   Send packet to server, return status
   -------------------------------------------------------------------- */

int  SendPacket(FILERCOM *pPacket, int function, WORD count, WORD size, BYTE *pData)
{
   WORD f, Checksum = 0;
   BYTE Signature[] = { 0x16, 0x16, 0x16, 0x10, 0x02 }; /* packet signature */

   if(size > PACKET_DATA_SIZE) return PACKET_TOO_LARGE;

#ifdef DEBUG_FILER
   printf("\n\nSENDING PACKET# : 0x%X\n", count);
   printf("SENDING function: 0x%X\n", function);
#endif

   /* send signature */
   for(f=0;f<5;f++) {
      SendByte(pPacket, Signature[f], 0);  /* no CRC yet */
   }

   /* send SOH (start of header) */
   Checksum = SendByte(pPacket, SOH, Checksum);  /* CRC starts here */

   /* send function (command request) */
   Checksum = SendByte(pPacket, function, Checksum);

   /* send packet count */
   Checksum = SendByte(pPacket, count, Checksum);

   /* send DM  (data marker) */
   Checksum = SendByte(pPacket, 0x01, Checksum);
   Checksum = SendByte(pPacket, 0x02, Checksum);

   /* process function request */
   switch(function) {

      case GET_DIR:
      case CONNECT_SERVER:
      case DISCONNECT_SERVER:
      case INIT_GET:
         break;  /* nothing else to say */

      case MAKE_DIR:
      case DEL_DIR:
      case DEL_FILE:
      case SEND_PATH:
      case SEND_FILENAME:
      case GET_FILENAME:
      case ASK_DIR:
         /* send path/filename size LO, HI */
         Checksum = SendByte(pPacket, size & 0xff, Checksum);
         Checksum = SendByte(pPacket, size >>0x08, Checksum);

         /* send path/filename */
         for(f=0;f<size;f++)
            Checksum = SendByte(pPacket, pData[f], Checksum);

         /* send Data End Marker */
         Checksum = SendByte(pPacket, 0x00, Checksum);
         Checksum = SendByte(pPacket, 0x00, Checksum);
         break;

      case SEND_DATA:
         /* double WORD size, MSB always zero */
         Checksum = SendByte(pPacket, 0x00, Checksum);
         Checksum = SendByte(pPacket, 0x00, Checksum);
         Checksum = SendByte(pPacket, size & 0xff, Checksum);
         Checksum = SendByte(pPacket, size >>0x08, Checksum);

         /* send data */
         for(f=0;f<size;f++)
            Checksum = SendByte(pPacket, pData[f], Checksum);

         break;

      case GET_DATA:
         /* double WORD size, MSB always zero */
         Checksum = SendByte(pPacket, 0x00, Checksum);
         Checksum = SendByte(pPacket, 0x00, Checksum);
         Checksum = SendByte(pPacket, size & 0xff, Checksum);
         Checksum = SendByte(pPacket, size >>0x08, Checksum);
         break;

      case DATA_END:
         Checksum = SendByte(pPacket, 0x00, Checksum);
         break;

      default:
         return INVALID_FUNCTION;
   }

   /* send CRCM (CRC Marker) */
   SendByte(pPacket, 0x10, 0);   /* No CRC on this one (tricky!) */
   Checksum = SendByte(pPacket, 0x03, Checksum);

   /* Finally send Checksum LO, HI */
   SendByte(pPacket, (Checksum & 0xff), 0);
   SendByte(pPacket, (Checksum >> 8), 0);

   return PACKET_SEND;   /* everything O.K. */

}

/* --------------------------------------------------------------------
                        Get packet from server
   -------------------------------------------------------------------- */

int GetPacket(FILERCOM *pPacket)
{

   int c=0, f, end_of_dir = 0;
   BYTE data = 0, crchi, crclo, sizehi, sizelo;
   WORD  Checksum = 0;
   BYTE Signature[] = { 0x16, 0x16, 0x16, 0x10, 0x02 }; /* packet signature */

   if(!pPacket) return SERVER_CLOSED;

   /* wait for signature till timeout */
   for(;;) {
      if(GetByte(pPacket, &data, NULL)==TIMEOUT) return TIMEOUT;
      if(data!=Signature[c++]) c=0;
      if(c==5) break;
   }

   /* get SOH */
   if(GetByte(pPacket, &data, &Checksum)==TIMEOUT) return TIMEOUT;
   if(data != SOH) return BAD_PACKET;

   /* get function */
   if(GetByte(pPacket, &data, &Checksum)==TIMEOUT) return TIMEOUT;
   pPacket->Function = data;

   /* get packet count */
   if(GetByte(pPacket, &data, &Checksum)==TIMEOUT) return TIMEOUT;
   pPacket->Count = data;

   /* get packet status */
   if(GetByte(pPacket, &data, &Checksum)==TIMEOUT) return TIMEOUT;
   pPacket->Status = data;

   /* get data marker */
   if(GetByte(pPacket, &data, &Checksum)==TIMEOUT) return TIMEOUT;
   if(data != 0x02) return BAD_PACKET;


   /* server replies */
   switch(pPacket->Function) {

      /* replies */
      case CONNECT_SERVER:
      case DISCONNECT_SERVER:
         /* data end marker */
         if(GetByte(pPacket, &data, &Checksum)==TIMEOUT) return TIMEOUT;
         if(data) return BAD_PACKET;
         if(GetByte(pPacket, &data, &Checksum)==TIMEOUT) return TIMEOUT;
         if(data) return BAD_PACKET;
         break;

      case MAKE_DIR:
      case DEL_DIR:
      case DEL_FILE:
      case SEND_PATH:
      case SEND_FILENAME:
      case GET_FILENAME:
      case SEND_DATA:
         /* get data marker and size MSB (always 0) */
         for(f=0;f<4;f++) {
            if(GetByte(pPacket, &data, &Checksum)==TIMEOUT) return TIMEOUT;
            if(data) return BAD_PACKET;
         }

         /* get data size */
         if(GetByte(pPacket, &data, &Checksum)==TIMEOUT) return TIMEOUT;
         sizelo = data;
         if(GetByte(pPacket, &data, &Checksum)==TIMEOUT) return TIMEOUT;
         sizehi = data;;
         pPacket->Size = (sizehi * 256) + sizelo;
         break;

      case DATA_END:
      case INIT_GET:
      case ASK_DIR:
         /* get data size & end marker (6 BYTEs) */
         for(f=0;f<6;f++) {
            if(GetByte(pPacket, &data, &Checksum)==TIMEOUT) return TIMEOUT;
            if(data) return BAD_PACKET;
         }
         break;

      /* data retreival */
      case GET_DATA:
         /* get data marker and size MSB (always 0) */
         for(f=0;f<4;f++) {
            if(GetByte(pPacket, &data, &Checksum)==TIMEOUT) return TIMEOUT;
            if(data) return BAD_PACKET;
         }

         /* get data size */
         if(GetByte(pPacket, &data, &Checksum)==TIMEOUT) return TIMEOUT;
         sizelo = data;
         if(GetByte(pPacket, &data, &Checksum)==TIMEOUT) return TIMEOUT;
         sizehi = data;;
         pPacket->Size = (sizehi * 256) + sizelo;

         for(f=0; f<pPacket->Size; f++) {
            if(GetByte(pPacket, &pPacket->pData[f], &Checksum)==TIMEOUT)
               return TIMEOUT;
         }

         break;

      case GET_DIR:
         /* get data marker and size MSB (always 0) */
         for(f=0;f<4;f++) {
            if(GetByte(pPacket, &data, &Checksum)==TIMEOUT) return TIMEOUT;
            if(data) return BAD_PACKET;
         }

         /* get data size */
         if(GetByte(pPacket, &data, &Checksum)==TIMEOUT) return TIMEOUT;
         sizelo = data;
         if(GetByte(pPacket, &data, &Checksum)==TIMEOUT) return TIMEOUT;
         sizehi = data;;
         pPacket->Size = (sizehi * 256) + sizelo;

         for(f=0; f<pPacket->Size; f++) {
            if(GetByte(pPacket, &pPacket->pData[f], &Checksum)==TIMEOUT)
               return TIMEOUT;
         }

         /* special 'dir' data end marker */
         if(GetByte(pPacket, &data, &Checksum)==TIMEOUT) return TIMEOUT;
         if((data!=0x01) && (data != 0x00)) return BAD_PACKET;
         if(data == 0x00) end_of_dir = 1;
         if(GetByte(pPacket, &data, &Checksum)==TIMEOUT) return TIMEOUT;
         if(data) return BAD_PACKET;
         if(GetByte(pPacket, &data, &Checksum)==TIMEOUT) return TIMEOUT;
         if(data) return BAD_PACKET;
         if(GetByte(pPacket, &data, &Checksum)==TIMEOUT) return TIMEOUT;
         if(data) return BAD_PACKET;

         break;

      default:
         return INVALID_FUNCTION;

   }

   /* get CRC Marker (no CRC on the next BYTE!) */
   if(GetByte(pPacket, &data, NULL)==TIMEOUT) return TIMEOUT;
   if(data != 0x10) return BAD_PACKET;
   if(GetByte(pPacket, &data, &Checksum)==TIMEOUT) return TIMEOUT;
   if(data != 0x03) return BAD_PACKET;

   /* get received CRC */
   if(GetByte(pPacket, &data, NULL)==TIMEOUT) return TIMEOUT;
   crclo = data;
   if(GetByte(pPacket, &data, NULL)==TIMEOUT) return TIMEOUT;
   crchi = data;
   pPacket->CRC16 = (crchi * 256) + crclo;

   /* check if CRC is good */
   if(pPacket->CRC16 != Checksum) return BAD_CRC;

#ifdef DEBUG_FILER
   printf("\n\nGOT PACKET# : 0x%X\n", pPacket->Count);
   printf("GOT Function: 0x%X\n", pPacket->Function);
   printf("GOT Status  : 0x%X\n", pPacket->Status);
   printf("GOT Size    : 0x%X\n", pPacket->Size);
#endif

   if(end_of_dir) return CANNOT_GET_ENTRY;
   return PACKET_RECVD;
}


/* --------------------------------------------------------------------
                      Talk (handshake) with server
   -------------------------------------------------------------------- */

int FilerRequest(FILERCOM *pFiler, int Request, WORD Size, BYTE *pData)

{
   int attempt = 0, stat;
   WORD Count;

   Count = pFiler->Count;

   /* packet handshake */
   while(attempt<NUM_OF_ATTEMPTS) {
      SendPacket(pFiler, Request, Count, Size, pData);
      stat=GetPacket(pFiler);
      if(stat==PACKET_RECVD) break;
      if(stat == CANNOT_GET_ENTRY) break;
      attempt++;
   }

   if(attempt==NUM_OF_ATTEMPTS) return NO_RESPONSE;
   if(pFiler->Function != (BYTE)Request) return BAD_REQUEST;
   if(pFiler->Count != Count) return BAD_PACKET_COUNT;

   /* update packet counter */
   Count++;
   pFiler->Count = Count;

   if(stat == CANNOT_GET_ENTRY) return stat;
   return SERVER_ACK;    /* client <> server agree */

}

/* --------------------------------------------------------------------
                      Open Filer communications
   -------------------------------------------------------------------- */

FILERCOM *FilerConnect(int PortNumber, unsigned long BaudRate, FLCB *pCb)
{

   int f;
   FILERCOM *pFiler;

   static unsigned int  port[]= {0, 0x3f8, 0x2f8, 0x3e8, 0x2e8 };

   static unsigned long BaudTable[]= {
      0,115200L,57600L,38400L,19200L,9600L,4800L,2400L,1200L,INV_BAUDRATE
   };

   /* check if PortNumber is valid (valid= 1 to 4) */
   if((PortNumber > 4)||(PortNumber ==0)) return NULL;

   /* check for valid baud-rate */
   for(f=0;f<10;f++) {
      if(BaudRate == BaudTable[f]) break;
   }
   if(BaudTable[f]==INV_BAUDRATE) return NULL;   /* invalid baudrate */

   /* allocate packet storage */
   if(!(pFiler = malloc(sizeof(FILERCOM)))) return NULL;

   /* packet structure defaults */
   pFiler->pData=0;
   pFiler->Function=0;
   pFiler->Count=0;
   pFiler->Status=0;
   pFiler->CRC16=0;
   pFiler->Port=port[PortNumber];
   pFiler->pCb = pCb;

   /* allocate data buffer storage */
   if(!(pFiler->pData = malloc(sizeof(FILERCOM)+PACKET_DATA_SIZE+100)))
      return NULL;

   if(!BaudRate) {
   /* Determine baudrate automatically if given baudrate == 0 */
      for(f=1;f<10;f++) {

         if(inportb(0x60)==1) {          /* ESC key pressed ? */
            free(pFiler->pData);
            free(pFiler);
            return NULL;
         }

         /* no response from server */
         if(BaudTable[f]==INV_BAUDRATE) {
            CloseAsync(pFiler->pAsync,0);  /* close port */
            free(pFiler->pData);
            free(pFiler);
            return NULL;
         }

         pFiler->Baud = BaudTable[f];
         pFiler->pAsync = OpenAsync(PortNumber,pFiler->Baud,
                                PAR_NONE,8,2,SIO_BUFFER,SIO_BUFFER);

         /* try 2 attempts */
         SendPacket(pFiler, CONNECT_SERVER, 0,0, NULL);
         if(GetPacket(pFiler)==PACKET_RECVD) break;

         SendPacket(pFiler, CONNECT_SERVER, 0,0, NULL);
         if(GetPacket(pFiler)==PACKET_RECVD) break;
      }
   }

   else {
      pFiler->Baud=BaudRate;
      pFiler->pAsync = OpenAsync(PortNumber,BaudRate,
                              PAR_NONE,8,2,SIO_BUFFER,SIO_BUFFER);

   }

   if(FilerRequest(pFiler, CONNECT_SERVER, 0, NULL) == NO_RESPONSE) {
      CloseAsync(pFiler->pAsync,0);  /* close port */
      free(pFiler->pData);
      free(pFiler);
      return NULL;
   }
   return pFiler;
}


/* --------------------------------------------------------------------
                     CloseServer channel (disconnect)
   -------------------------------------------------------------------- */

int FilerDisconnect(FILERCOM *pFiler)
{

   if(!pFiler) return SERVER_CLOSED;
   pFiler->Count=0;

   if(FilerRequest(pFiler, DISCONNECT_SERVER, 0, NULL) == NO_RESPONSE) {
      return NO_RESPONSE;
   }

   CloseAsync(pFiler->pAsync,0);  /* close port */
   free(pFiler->pData);
   free(pFiler);

   return SERVER_CLOSED;

}


